# Permissions Task 1

## Instructions:

####Do the following as the user root:

### 1. Perform the following group related tasks:
#### 1.1 Create the /root/consultants directory
#### 1.2 Create a group named consultants
#### 1.3 Change the group ownership of the consultants directory to consultants
#### 1.4 Add write permission to the consultants group
#### 1.5 No one else except the owner and group should be able to access the consultants directory.
#### 1.6 Create an empty file called consultant1.txt in the consultants directory.
#### 1.7 Change the group ownership of the consultant1.txt file to wheel.
#### 1.8 Add the text "Hello world" to the consultant1.txt file.
#### 1.9 Make the consultant1.txt file world writeable.
