# Rsyslog

For information on journalctl, go to the Systemd page.

Rsyslog needs the rsyslogd service to be running.

The configuration file is in "/etc/rsyslog.conf".
Drop files can be places in "/etc/rsyslog.d/"

Read https://www.rsyslog.com/doc/master/index.html and add to this page.