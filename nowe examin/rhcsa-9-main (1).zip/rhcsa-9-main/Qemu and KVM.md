# Qemu and KVM

## Disk management

Expand disk by 2GiB.
``sudo qemu-img resize  /var/lib/libvirt/images/rhel9.3.qcow2 +2G``
