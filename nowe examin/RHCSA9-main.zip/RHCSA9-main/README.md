Download Sublime 3 for an enhanced experience with the attached .txt file : https://www.sublimetext.com/

